# MasterX APK
1. Upload all these files to a new GitHub repo (keep the .github folder).
2. Actions tab -> "Build Android APK" runs automatically.
3. When finished, open the run -> Artifacts -> MasterX-APK -> download, unzip, install app-debug.apk.
