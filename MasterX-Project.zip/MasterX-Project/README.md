# MasterX Study

Sri Lankan students ලාට Grade 6 සිට A/L දක්වා study app එකක්.

## Structure
```
index.html                      main app
manifest.webmanifest            PWA manifest
static/icon-192.png, icon-512.png
.github/workflows/deploy.yml    auto-deploy to GitHub Pages
```

## Deploy (GitHub Pages)
1. Repo එකට ඔක්කොම files push කරන්න (branch: `main`).
2. Settings -> Pages -> Source = **GitHub Actions**.
3. ඊළඟ push එකෙන් site එක live වෙනවා.

## Note
GitHub Pages = static hosting only. `/api/*`, `/add_task`, `/store` වගේ backend routes
වැඩ කරන්න server එකක් (Flask/Node) වෙනම host කරන්න ඕනේ.
