# MasterX Study

Static home page for MasterX Study (`index.html`).

## Deploy (GitHub Pages)
1. Push this whole folder to a GitHub repo (branch `main`).
2. Settings -> Pages -> Source -> **GitHub Actions**.
3. Every push to `main` publishes `index.html` automatically
   (workflow: `.github/workflows/deploy.yml`).
